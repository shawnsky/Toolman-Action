<html>
<head>
<title>Ampache/Plex Configuration</title>
<link rel="stylesheet" href="style.css" />
</head>
<body>
<div id="main">
<div id="maincontainer">
<img src="/images/plex-icon-256.png" />
